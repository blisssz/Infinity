Algemeen:

Druk de Linkermuisknop om te schieten.
Druk de Rechtermuisknop om te schieten of met herladen.


Toetsen van 1 wisselt het wapen tussen aan en uit.

Indrukken van W is vooruit.
Indrukken van A is linksopzij.
Indrukken van D is rechtsopzij.
Indrukken van S is achteruit.

Spatiebalk drukken laat het karakter Springen.

Op Esc drukken geeft het Pauzemenu.

Wapen specifiek:

Grappling hook
Q ingedrukt houden laat het touw vieren.
E ingedrukt houden haalt het touw in.

Gravity Gun
Linkermuisknop langer inhouden geeft de projectielen een grotere zwaartekracht.

PogoStick
Indien de PogoStick in gebruik is, dan gaat men op of af met de linkermuisknop.

Guns

Het pistool, machinegeweer of de rifle herlaadt met de rechtermuisknop
Linker shift ingedrukt houden om te aimen.
